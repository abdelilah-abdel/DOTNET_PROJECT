﻿using l9ithotel.Help;
using l9ithotel.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Web.Security;

namespace l9ithotel.Controllers
{
    public class LoginController : Controller
    {
        // GET: Login
        public ActionResult Login()
        {
            return View();
        }
        [HttpPost]
        public ActionResult Login(Login login)
        {
            if (ModelState.IsValid)
            {
                l9ithotelEntities2 db = new l9ithotelEntities2();
                bool verifyPassword=false;
                var user = db.User.Where(a => a.UserEmail == login.Email).FirstOrDefault();
                if(user != null)
                {
                    verifyPassword = Password.VerifyPassword(user, login.Password);
                }
                if (verifyPassword)
                {
                    var Ticket = new FormsAuthenticationTicket(login.Email, true, 3000);
                    string Encrypt = FormsAuthentication.Encrypt(Ticket);
                    var Cookie = new HttpCookie(FormsAuthentication.FormsCookieName, Encrypt);
                    Cookie.Expires=DateTime.Now.AddHours(3000);
                    Cookie.HttpOnly= true;
                    Response.Cookies.Add(Cookie);
                    if (user.RoleId == 1)
                    {
                        return RedirectToAction("Index", "Home");
                    }
                    else if(user.RoleId == 2)
                    {
                        return RedirectToAction("Index", "Home");
                    }
                    else
                    {
                        return RedirectToAction("Index", "Home");
                    }
                }
                return View();
            }
            else
                return View();
        }

        public ActionResult Logout()
        {
            FormsAuthentication.SignOut();
            return RedirectToAction("Index", "Home");
        }
        
    }
}