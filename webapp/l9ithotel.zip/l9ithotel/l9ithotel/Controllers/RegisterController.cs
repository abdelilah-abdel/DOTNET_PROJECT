﻿using l9ithotel.Help;
using l9ithotel.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace l9ithotel.Controllers
{
    public class RegisterController : Controller
    {
        // GET: Register
        public ActionResult Register()
        {
            return View();
        }
        [HttpPost]
        public ActionResult Register(User user)
        {
            if (ModelState.IsValid)
            {
                l9ithotelEntities2 db = new l9ithotelEntities2();
                User user1 = db.User.Where(e => e.UserEmail == user.UserEmail).FirstOrDefault();
                if(user1 != null)
                {
                    ViewBag.message = "Cette adresse email est déjà associée à un compte";
                    return View();
                }
                user.RoleId = 1;
                Password.HashPassword(user, user.UserPassWord);
                //user.UserPassWord = Password.encodePassword(user.UserPassWord);
                db.User.Add(user);
                db.SaveChanges();
                ModelState.Clear();
                return RedirectToAction("Login", "Login");
            }
            return View();
        }
    }
}