﻿using l9ithotel.Models;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Web.Security;

namespace l9ithotel.Controllers
{
    public class HotelController : Controller
    {
        // GET: Hotel
        [Authorize]
        
        public ActionResult Details(int id)
        {
            l9ithotelEntities2 db = new l9ithotelEntities2();
            var query = db.Hotel.Where(e => e.HotelId == id).FirstOrDefault();
            var photos=db.Images.Where(e=>e.HotelId==query.HotelId && e.OffreId==null).Select(e=>e.ImageHotel).ToList();
            ViewData["items"]=photos;
            return View(query);
        }
        [Authorize(Roles = "Admin")]
        public ActionResult Delete(int id)
        {
            l9ithotelEntities2 db = new l9ithotelEntities2();
            Hotel hotel = db.Hotel.Where(e => e.HotelId == id).FirstOrDefault();
            List<Images> images= db.Images.Where(e => e.HotelId == hotel.HotelId).ToList();
            List<Offre> offres = db.Offre.Where(e => e.HotelId == hotel.HotelId).ToList();
            User user = Login.getUserByEmail(db.User.Where(e=>e.UserId==hotel.UserId).FirstOrDefault().UserEmail);
            db.Images.RemoveRange(images);
            db.Offre.RemoveRange(offres);
            db.Hotel.Remove(hotel);
            db.SaveChanges();
            Hotel existOther = db.Hotel.Where(e=>e.UserId==user.UserId).FirstOrDefault();
            if(existOther == null)
            {
                if(user.RoleId!=3)
                    Roles.RemoveUserFromRole(user.UserEmail, "Gerant");
            }
            string referrer = Request.UrlReferrer.AbsolutePath;
            string[] parts = referrer.Split('/');
            string actionName = parts[2];
            string controllerName = parts[1];
            if (actionName == "Details")
                return RedirectToAction("index", "Home");
            return RedirectToAction(actionName, controllerName);
        }
        public ActionResult RechercheParNom(string nom)
        {
            nom=nom.ToLower();
            l9ithotelEntities2 db = new l9ithotelEntities2();
            var query = db.Hotel.Where(e => e.HotelName.ToLower().Contains(nom) && e.Accepted==true).ToList();
            return View(query);
        }
        [Authorize]
        public ActionResult DemandeAjoutHotel()
        {
            return View();
        }
        [HttpPost]
        [Authorize]
        public ActionResult DemandeAjoutHotel(Hotel hotel)
        {
            if (ModelState.IsValid)
            {
                l9ithotelEntities2 db = new l9ithotelEntities2();
                hotel.StarsReviews = 0;
                hotel.Accepted = false;
                hotel.UserId = Login.getUserByEmail(User.Identity.Name).UserId;
                db.Hotel.Add(hotel);
                db.SaveChanges();
                Images image = new Images();

                HttpPostedFileBase imageCourante;
                if (Request.Files.Count > 0)
                {
                    for (int i = 0; i < Request.Files.Count; i++)
                    {
                        // Récupération de l'image courante
                        imageCourante = Request.Files[i];

                        // Vérification de la présence d'un contenu dans l'image courante
                        if (imageCourante != null && imageCourante.ContentLength > 0)
                        {
                            // Enregistrement de l'image dans la base données
                            image.HotelId = hotel.HotelId;
                            image.ImageHotel = new byte[imageCourante.ContentLength];
                            imageCourante.InputStream.Read(image.ImageHotel, 0, imageCourante.ContentLength);
                            db.Images.Add(image);
                            db.SaveChanges();
                        }
                    }
                }
                ViewBag.message = "Demande envoyée avec succés";
                return View();
            }
            else
                return View();
        }
        public ActionResult GestionDemande()
        {
            l9ithotelEntities2 db = new l9ithotelEntities2();
            var query = db.Hotel.Where(e => e.Accepted == false).ToList();
            return View(query);
        }
        public ActionResult AccepterDemande(int id)
        {
            l9ithotelEntities2 db = new l9ithotelEntities2();
            var query = db.Hotel.Where(e => e.HotelId == id).FirstOrDefault().Accepted = true;
            var hotel = db.Hotel.Where(e => e.HotelId == id).FirstOrDefault();
            var user = db.User.Where(e => e.UserId == hotel.UserId).FirstOrDefault();
            db.SaveChanges();
            if (user.RoleId ==1)
            {
                Roles.AddUserToRole(user.UserEmail, "Gerant");
            }

            return RedirectToAction("GestionDemande", "Hotel");
        }
        public ActionResult RecherchePersonnalise()
        {
            return View();
        }
        [HttpPost]
        public ActionResult ResultatRecherchePersonnalise(string nomHotel, string villeHotel, string maxStars, string minStars)
        {
            nomHotel=nomHotel.ToLower();
            villeHotel = villeHotel.ToLower();
            maxStars= maxStars.Replace('.', ',');
            minStars= minStars.Replace('.', ',');
            float max=0;
            float min=0;
            if (maxStars != "")
                max = Convert.ToSingle(maxStars);
            if(minStars != "")
                min = Convert.ToSingle(minStars);
            l9ithotelEntities2 db = new l9ithotelEntities2();
            var query=db.Hotel.Where(e=>e.Accepted==true).OrderBy(e=>e.StarsReviews).ToList();
            if(nomHotel != null && nomHotel!="")
            {
                query = query.Where(e => e.HotelName.ToLower().Contains(nomHotel)).ToList();
            }
            if(villeHotel != null && villeHotel!="")
            {
                query = query.Where(e => e.HotelCity.ToLower() == villeHotel).ToList();
            }
            if(minStars != null && minStars != "")
            {
                query = query.Where(e => e.StarsReviews >= min).ToList();
            }
            if(maxStars!=null && maxStars !="")
            {
                query = query.Where(e => e.StarsReviews <= max).ToList();
            }
            if((nomHotel == null || nomHotel=="") && (villeHotel==null || villeHotel=="") && (maxStars =="" || maxStars==null) && (minStars=="" || minStars==null) )
            {
                return RedirectToAction("Index", "Home");
            }
            return View(query);
        }
        
    }
}