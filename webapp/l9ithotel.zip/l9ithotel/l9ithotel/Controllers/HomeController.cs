﻿using l9ithotel.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace l9ithotel.Controllers
{
    public class HomeController : Controller
    {
        // GET: Home
        public ActionResult Index()
        {
            l9ithotelEntities2 db = new l9ithotelEntities2();
            var query = db.Hotel.Where(e => e.Accepted == true).ToList();
            return View(query);
        }

        public ActionResult About()
        {
            return View();
        }
    }
}