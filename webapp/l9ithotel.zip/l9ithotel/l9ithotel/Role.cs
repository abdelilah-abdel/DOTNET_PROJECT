﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Security;
using l9ithotel.Models;

namespace l9ithotel
{
    public class Role : RoleProvider
    {
        public override string ApplicationName { get; set; }

        public override void AddUsersToRoles(string[] usernames, string[] roleNames)
        {
            l9ithotelEntities2 db = new l9ithotelEntities2();
            foreach (var user in usernames)
            {
                db.User.Where(e => e.UserEmail == user).FirstOrDefault().RoleId = 2;
                db.SaveChanges();
            }
        }

        public override void CreateRole(string roleName)
        {
            throw new NotImplementedException();
        }

        public override bool DeleteRole(string roleName, bool throwOnPopulatedRole)
        {
            throw new NotImplementedException();
        }

        public override string[] FindUsersInRole(string roleName, string usernameToMatch)
        {
            throw new NotImplementedException();
        }

        public override string[] GetAllRoles()
        {
            throw new NotImplementedException();
        }

        public override string[] GetRolesForUser(string username)
        {
            l9ithotelEntities2 db = new l9ithotelEntities2();
            var user = db.User.Include("UserRole").Where(a => a.UserEmail == username).FirstOrDefault().UserRole.RoleName;
            string[] role= { user };
            return role;
        }

        public override string[] GetUsersInRole(string roleName)
        {
            throw new NotImplementedException();
        }

        public override bool IsUserInRole(string username, string roleName)
        {
            throw new NotImplementedException();
        }

        public override void RemoveUsersFromRoles(string[] usernames, string[] roleNames)
        {
            l9ithotelEntities2 db = new l9ithotelEntities2();
            foreach (var user in usernames)
            {
                db.User.Where(e => e.UserEmail == user).FirstOrDefault().RoleId = 1;
                db.SaveChanges();
            }
        }

        public override bool RoleExists(string roleName)
        {
            throw new NotImplementedException();
        }
    }
}