﻿using l9ithotel.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Cryptography;
using System.Web;

namespace l9ithotel.Help
{
    public class Password
    {
        //public static string encodePassword(string password)
        //{
        //    try
        //    {
        //        byte[] EncDataByte = new byte[password.Length];
        //        EncDataByte=System.Text.Encoding.UTF8.GetBytes(password);
        //        string EncryptedData = Convert.ToBase64String(EncDataByte);
        //        return EncryptedData;
        //    }
        //    catch(Exception ex)
        //    {
        //        throw new Exception("erreur de cryptage du mot de passe :"+ex.Message+"\n veuillez essayer ultériairement, si le problème persiste, veuillez contacter les responsables technique");
        //    }
        //}
        public static void HashPassword(User user, string password)
        {
            byte[] salt;
            new RNGCryptoServiceProvider().GetBytes(salt = new byte[16]);
            var pbkdf2 = new Rfc2898DeriveBytes(password, salt, 10000);
            byte[] hash = pbkdf2.GetBytes(20);
            user.UserSalt = Convert.ToBase64String(salt);
            user.UserPassWord = Convert.ToBase64String(hash);
        }

        public static bool VerifyPassword(User user, string password)
        {
            /* Extract the bytes */
            byte[] salt = Convert.FromBase64String(user.UserSalt);
            byte[] hash = Convert.FromBase64String(user.UserPassWord);
            /* Compute the hash on the password the user entered */
            var pbkdf2 = new Rfc2898DeriveBytes(password, salt, 10000);
            byte[] newHash = pbkdf2.GetBytes(20);
            /* Compare the results */
            return hash.SequenceEqual(newHash);
        }
    }
}