using l9ithotel.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Web.Routing;

namespace l9ithotel
{
    public class MvcApplication : System.Web.HttpApplication
    {
        protected void Application_Start()
        {
            using(l9ithotelEntities2 db =new l9ithotelEntities2())
            {
                if (db.UserRole.Count()==0)
                {
                    var role1 = new UserRole();
                    var role2 = new UserRole();
                    var role3 = new UserRole();
                    role1.RoleName = "SimpleUser";
                    role2.RoleName = "Gerant";
                    role3.RoleName = "Admin";
                    db.UserRole.Add(role1);
                    db.UserRole.Add(role2);
                    db.UserRole.Add(role3);
                    db.SaveChanges();
                }
            }
            AreaRegistration.RegisterAllAreas();
            RouteConfig.RegisterRoutes(RouteTable.Routes);
        }
    }
}
